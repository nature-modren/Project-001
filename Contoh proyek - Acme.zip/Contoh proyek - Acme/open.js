//function namafungsi(){
   // alert("aman");
//}
//function namafungsi2(){
   // console.log("bahaya")
//}
//function namafungsi3(){
  //  alert("emergency ")
//}

//namafungsi()
//namafungsi2()
//namafungsi()


/*confirm();*/


//getminute()
//prompt("gagal atau sukses")
//if(false) {
   // console.log("sukses")
//}else if(false){
 //   console.log("gagal")
//}else{
 //   console.log("gagal")
//}


//namafungsi();

//c = 0;
//b = 6;
//f = 8;
//console.time(c)
//console.timeEnd(c)
//console.info("yet")
//let x = Math.Pi;
//console.log(x)

for(var i= 1 ; i<=100 ; i++){
    console.log("i")
}

